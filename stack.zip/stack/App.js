import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import {NavigationContainer} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
import {createAppContainer} from 'react-native'

import HomeScreen from './components/HomeScreen';
import AboutScreen from './components/Aboutscreen';



export default function App() {
  return (
    <NavigationContainer>
    <Stack.Navigator useLegacyImplementation initialRouteName = 'HomeScreen'>
    <Stack.Screen name='AboutScreen' component={AboutScreen}/>
    <Stack.Screen name='HomeScreen' component={HomeScreen}/>
    </Stack.Navigator>
    </NavigationContainer>
  );
}

