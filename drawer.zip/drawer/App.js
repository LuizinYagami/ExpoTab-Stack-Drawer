import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import {NavigationContainer} from '@react-navigation/native';
import {createDrawerNavigator} from '@react-navigation/drawer';

import HomeScreen from './components/HomeScreen';
import AboutScreen from './components/AboutScreen';
import ContactScreen from './components/ContactScreen';

const Drawer = createDrawerNavigator();

export default function App() {
  return (
    <NavigationContainer>
    <Drawer.Navigator useLegacyImplementation initialRouteName = 'HomeScreen'>
    <Drawer.Screen name='AboutScreen' component={AboutScreen}/>
    <Drawer.Screen name='HomeScreen' component={HomeScreen}/>
    <Drawer.Screen name='ContactScreen' component={ContactScreen}/>
    </Drawer.Navigator>
    </NavigationContainer>
  );
}
